<!-- ======= About Us Section ======= -->
<section id="about-us" class="about-us padd-section">
  <div class="container" style="margin-bottom: 30px">
    <h4 class="text-center">
      "Tuhan membuat segala sesuatu indah pada waktunya,<br>
      indah saat Dia mempertemukan, indah saat Dia menumbuhkan kasih,</br>
      dan indah saat Dia mempersatukan kami dalam suatu pernikahan kudus"
    </h4>
  </div>
  <div class="container" data-aos="fade-up">
      <div class="row justify-content-center">

        <div class="col-md-4">
          <div class="about-content text-pria text-right" data-aos="fade-left" data-aos-delay="100">

            <h3><span>Yizhar Putra Wahyu Pamekas</span></h3>
            <p>
              Putra dari Bpk. Isman Suwito
              dan Ibu Mukti Wahyu Ningsih
            </p>
          </div>
        </div>

        <div class="col-md-2">
          <img src="{{ asset('multimedia/putralois/putra.jpg') }}" alt="About" data-aos="zoom-in" data-aos-delay="100">
        </div>

        <div class="col-md-2">
          <img src="{{ asset('multimedia/putralois/lois.jpg') }}" alt="About" data-aos="zoom-in" data-aos-delay="100">
        </div>

        <div class="col-md-4">
          <div class="about-content text-wanita" data-aos="fade-left" data-aos-delay="100">

            <h3><span>Lois Aprilia Irianti</span></h3>
            <p>
              Putri dari Bpk. Agus Legowo Suharjanto, A.Md.Kep
              dan Ibu Wiji Astuti, A.Md.Kep
            </p>
          </div>
        </div>
        
      </div>
  </div>
</section><!-- End About Us Section -->