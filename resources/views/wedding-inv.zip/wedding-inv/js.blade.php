  <script src="{{ asset('assets/js/jquery.min.js') }}"></script>

  <!-- Vendor JS Files -->
  <script src="{{ asset('assets_eStartup/vendor/aos/aos.js') }}"></script>
  <script src="{{ asset('assets_eStartup/vendor/bootstrap/js/bootstrap.bundle.min.js') }}"></script>
  <script src="{{ asset('assets_eStartup/vendor/glightbox/js/glightbox.min.js') }}"></script>
  <script src="{{ asset('assets_eStartup/vendor/swiper/swiper-bundle.min.js') }}"></script>
  <script src="{{ asset('assets_eStartup/vendor/php-email-form/validate.js') }}"></script>

  <!-- Required datatable js -->
  <script src="{{ asset('assets/plugins/datatables/jquery.dataTables.min.js') }}"></script>
  <script src="{{ asset('assets/plugins/datatables/dataTables.bootstrap4.min.js') }}"></script>

  <!-- Responsive examples -->
  <script src="{{ asset('assets/plugins/datatables/dataTables.responsive.min.js') }}"></script>
  <script src="{{ asset('assets/plugins/datatables/responsive.bootstrap4.min.js') }}"></script>

  <!-- Template Main JS File -->
  <script src="{{ asset('assets_eStartup/js/main.js') }}"></script>
  @include('wedding-inv.script-js')
