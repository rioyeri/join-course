<!-- ======= Hero Section ======= -->
<section id="hero" class="bg" style="background-image: url({{ asset('multimedia/putralois/banner.jpg') }})">
  <div class="hero-container" data-aos="fade-in">
    {{-- <div class="carousel-background"><img src="{{ asset('assets/images/banner/banner radio.jpg') }}" alt=""></div> --}}
    <h2>Pernikahan</h2>
    <h1 data-aos="zoom-out" data-aos-delay="100"><strong>Putra</strong> <span>&</span> <strong>Lois</strong></h1>
    <h4><strong>Sabtu, 12 Februari 2022</strong></h4>
    <h5>Teruntuk</h5>
    <h4><strong>{{ $nama }}</strong></h4>
    <h5>di {{ $posisi }}</h5>
    {{-- <img src="assets_eStartup/img/hero-img.png" alt="Hero Imgs" data-aos="zoom-out" data-aos-delay="100"> --}}
    <a href="#about-us" class="btn-get-started scrollto" onClick="music();">Pemberitahuan</a>
  </div>
</section><!-- End Hero Section -->