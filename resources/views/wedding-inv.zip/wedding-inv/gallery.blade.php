<style>
  .image-fit{
      object-fit:cover;
      width:415px;
      height:415px;
      border: solid 1px #CCC
  }
</style>
<!-- ======= Screenshots Section ======= -->
<section id="screenshots" class="padd-section text-center">

    <div class="container" data-aos="fade-up">
      <div class="section-title text-center">
        <h2>Galeri Foto</h2>
        <p class="separator">Beberapa potret kebahagiaan kami</p>
      </div>

      <div class="screens-slider swiper">
        <div class="swiper-wrapper align-items-center">
          <div class="swiper-slide"><img src="{{ asset('multimedia/putralois/galleries/1.jpg') }}" class="img-fluid image-fit" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('multimedia/putralois/galleries/2.jpg') }}" class="img-fluid image-fit" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('multimedia/putralois/galleries/3.jpg') }}" class="img-fluid image-fit" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('multimedia/putralois/galleries/4.jpg') }}" class="img-fluid image-fit" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('multimedia/putralois/galleries/5.jpg') }}" class="img-fluid image-fit" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('multimedia/putralois/galleries/6.jpg') }}" class="img-fluid image-fit" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('multimedia/putralois/galleries/7.jpg') }}" class="img-fluid image-fit" alt=""></div>
          <div class="swiper-slide"><img src="{{ asset('multimedia/putralois/galleries/8.jpg') }}" class="img-fluid image-fit" alt=""></div>
        </div>
        <div class="swiper-pagination"></div>
      </div>
    </div>

  </section><!-- End Screenshots Section -->