<!-- ======= Features Section ======= -->
<section id="features" class="padd-section text-center">

    <div class="container" data-aos="fade-up">
      <div class="section-title text-center">
        <h2>Hadiah Pernikahan</h2>
        <p class="separator">Untuk Keluarga dan teman yang ingin memberikan hadiah berupa Uang, Kami mengucapkan Terima Kasih dan dengan senang hati menerimanya. Dapat ditransfer melalui :</p>
      </div>

      <div class="row" data-aos="fade-up" data-aos-delay="100">

        <div class="col-md-6 col-lg-6">
          <div class="feature-block">
            <h6>BRI</h6>
            <h6>a.n. Putra Wahyu Pamekas</h6>
            <h4 style="margin-top: 20px;">658301023016539</h4>
            <a href="javascript:;" id="norekputra" data-toggle="popover" class="btn-rounded" onclick="copyNumber(658301023016539)">Salin Nomor Rekening</a>
          </div>
        </div>

        <div class="col-md-6 col-lg-6">
          <div class="feature-block">
            <h6>BTPN</h6>
            <h6>a.n. Lois Aprilia Irianti</h6>
            <h4 style="margin-top: 20px;">90270167617</h4>
            <a href="javascript:;" id="noreklois" data-toggle="popover" class="btn-rounded" onclick="copyNumber(90270167617)">Salin Nomor Rekening</a>
          </div>
        </div>

      </div>
    </div>
  </section><!-- End Features Section -->