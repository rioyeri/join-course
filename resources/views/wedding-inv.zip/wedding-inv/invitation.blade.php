<!-- ======= Get Started Section ======= -->
<section id="get-started" class="padd-section text-center">

    <div class="row">
      {{-- <div class="col-4"></div> --}}
      <div class="col-12">
        <div class="container" data-aos="fade-up">
          <div class="section-title text-center">

            <h2>Acara</h2>
            <p class="separator pull-center">Kami menyampaikan kabar bahagia ini dan akan lengkap apabila anda berkenan memberikan doa restu kepada kami dalam acara pernikahan kami berikut ini</p>

          </div>
        </div>
      </div>
      {{-- <div class="col-4"></div> --}}
    </div>

    <div class="container">
      <div class="row">

        <div class="col-md-6 col-lg-6" data-aos="zoom-in" data-aos-delay="100">
          <div class="feature-block">
            <div class="row">
              <div class="col-5 text-center">
                <h3>Pemberkatan</h3>
                <h6 id="countdown_pemberkatan_hari"></h6>
                <h6 id="countdown_pemberkatan_waktu"></h6>
              </div>
              <div class="col-7">
                <h5>Sabtu, 12 Februari 2022 || 08.30 WIB - Selesai</h5>
                <h5>di <strong>GPT "Kristus Bintang Fajar"</strong></h5>
                <h5>Tamanan-Tulungagung</h5>
                <h5 style="margin-top: 5px">Live Streaming di Channel Youtube</h5>
                <h5><strong>"PELITA GPT TULUNGAGUNG"</strong></h5>
                <a href="#" class="btn-rounded" target="_blank">Tonton Live Streaming</a>
              </div>
            </div>
          </div>
        </div>

        <div class="col-md-6 col-lg-6" data-aos="zoom-in" data-aos-delay="200">
          <div class="feature-block">
            <div class="row">
              <div class="col-5 text-center">
                <h3>Acara</h3>
                <h6 id="countdown_resepsi_hari"></h6>
                <h6 id="countdown_resepsi_waktu"></h6>
              </div>
              <div class="col-7">
                <h6>Sabtu, 12 Februari 2022</h6>
                <h6>18.00 - 21.00 WIB</h6>
                <h6>di <strong>"Jepun View Resto"</strong></h6>
                <h6>Jl. Mayor Sujadi, Jepun, Tulungagung</h6>
                <a href="https://maps.app.goo.gl/YBRsesxrGXouM9u67" target="_blank" class="btn-rounded">Lihat Lokasi</a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>

    <div class="row" style="margin-top: 50px;">
      <div class="col-2"></div>
      <div class="col-8">
        <div class="container" data-aos="fade-up">
          <div class="section-title text-center">
            <h4>Protokol Kesehatan</h4>
            <p class="separator pull-center">
              Mohon untuk anda sahabat/kerabat dan saudara untuk tetap memperhatikan protokol kesehatan yaitu Menggunakan Masker, Menjaga Jarak, Mencuci Tangan dan selalu menjaga kesehatan dan juga imun tubuh. Terima kasih
            </p>
          </div>
        </div>
      </div>
      <div class="col-2"></div>
    </div>

  </section><!-- End Get Started Section -->