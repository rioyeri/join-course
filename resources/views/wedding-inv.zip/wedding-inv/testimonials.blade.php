    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="padd-section text-center">
        <div class="container" data-aos="fade-up">
          <div class="row justify-content-center">
  
            <div class="col-md-8">
  
              <div class="testimonials-content">
                <div id="carousel-example-generic" class="carousel slide" data-bs-ride="carousel">
  
                  <div class="carousel-inner" role="listbox">
  
                    <div class="carousel-item  active">
                      <div class="top-top">
  
                        <h2>Our Users Speack volumes us</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type
                          specimen book. It has survived not only five centuries.</p>
                        <h4>Kimberly Tran<span>manager</span></h4>
  
                      </div>
                    </div>
  
                    <div class="carousel-item ">
                      <div class="top-top">
  
                        <h2>Our Users Speack volumes us</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type
                          specimen book. It has survived not only five centuries.</p>
                        <h4>Henderson<span>manager</span></h4>
  
                      </div>
                    </div>
  
                    <div class="carousel-item ">
                      <div class="top-top">
  
                        <h2>Our Users Speack volumes us</h2>
                        <p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type
                          specimen book. It has survived not only five centuries.</p>
                        <h4>David Spark<span>manager</span></h4>
  
                      </div>
                    </div>
  
                  </div>
  
                  <div class="btm-btm">
  
                    <ul class="list-unstyled carousel-indicators">
                      <li data-bs-target="#carousel-example-generic" data-bs-slide-to="0" class="active"></li>
                      <li data-bs-target="#carousel-example-generic" data-bs-slide-to="1"></li>
                      <li data-bs-target="#carousel-example-generic" data-bs-slide-to="2"></li>
                    </ul>
  
                  </div>
  
                </div>
              </div>
            </div>
  
          </div>
        </div>
      </section><!-- End Testimonials Section -->